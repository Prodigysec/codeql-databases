package lingyiwanwu

// https://platform.lingyiwanwu.com/docs

var ModelList = []string{
	"yi-large", "yi-medium", "yi-vision", "yi-medium-200k", "yi-spark", "yi-large-rag", "yi-large-turbo", "yi-large-preview", "yi-large-rag-preview",
}

var ChannelName = "lingyiwanwu"
