package ai360

var ModelList = []string{
	"360gpt-turbo",
	"360gpt-turbo-responsibility-8k",
	"360gpt-pro",
	"360gpt2-pro",
	"360GPT_S2_V9",
	"embedding-bert-512-v1",
	"embedding_s1_v1",
	"semantic_similarity_s1_v1",
}

var ChannelName = "ai360"
