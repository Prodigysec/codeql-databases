package mokaai

var ModelList = []string{
	"m3e-large",
	"m3e-base",
	"m3e-small",
}

var ChannelName = "mokaai"
