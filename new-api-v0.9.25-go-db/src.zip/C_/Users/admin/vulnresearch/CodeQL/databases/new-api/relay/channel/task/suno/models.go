package suno

var ModelList = []string{
	"suno_music", "suno_lyrics",
}

var ChannelName = "suno"
