package jimeng

const (
	ChannelName = "jimeng"
)

var ModelList = []string{
	"jimeng_high_aes_general_v21_L",
}
