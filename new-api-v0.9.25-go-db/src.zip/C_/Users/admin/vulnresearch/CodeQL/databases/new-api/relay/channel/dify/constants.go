package dify

var ModelList []string

var ChannelName = "dify"
