package sora

var ModelList = []string{
	"sora-2",
	"sora-2-pro",
}

var ChannelName = "sora"
